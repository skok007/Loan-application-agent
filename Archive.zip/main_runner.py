import asyncio
from agents import Runner
from data_model import LoanApplicationJourney, TrendAnalysisResult
from agents.orchestrator_agent import orchestrator_agent
from agents.report_agent import report_agent, mcp_server
from datetime import datetime

async def run_pipeline(app: LoanApplicationJourney):
    await mcp_server.__aenter__()
    
    orchestrated = await Runner.run(
        orchestrator_agent,
        input="Perform all checks and prepare summary.",
        context=app
    )

    result_obj = TrendAnalysisResult(
        application_id=app.application_id,
        sla_result="Called via tool",
        fraud_result="Called via tool",
        recommendation="Embedded in summary",
        explanation="Embedded in summary",
        timestamp=datetime.now().isoformat()
    )

    final = await Runner.run(report_agent, input="Send final report", context=result_obj)
    print("\n✅ Report sent via MCP:\n", final.final_output)

    await mcp_server.__aexit__(None, None, None)
